---
name: Botanical Serenity
colors:
  surface: '#f1fcf2'
  surface-dim: '#d1ddd3'
  surface-bright: '#f1fcf2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ebf7ed'
  surface-container: '#e5f1e7'
  surface-container-high: '#e0ebe1'
  surface-container-highest: '#dae5dc'
  on-surface: '#141e18'
  on-surface-variant: '#434844'
  inverse-surface: '#29332c'
  inverse-on-surface: '#e8f4ea'
  outline: '#737874'
  outline-variant: '#c3c8c3'
  surface-tint: '#516258'
  primary: '#15251d'
  on-primary: '#ffffff'
  primary-container: '#2a3b32'
  on-primary-container: '#92a599'
  inverse-primary: '#b8cbbf'
  secondary: '#4b635a'
  on-secondary: '#ffffff'
  secondary-container: '#cde9dc'
  on-secondary-container: '#516a60'
  tertiary: '#3e1600'
  on-tertiary: '#ffffff'
  tertiary-container: '#5d2806'
  on-tertiary-container: '#dc8e64'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e7da'
  primary-fixed-dim: '#b8cbbf'
  on-primary-fixed: '#0e1f17'
  on-primary-fixed-variant: '#394b41'
  secondary-fixed: '#cde9dc'
  secondary-fixed-dim: '#b2ccc1'
  on-secondary-fixed: '#072018'
  on-secondary-fixed-variant: '#344c43'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#713714'
  background: '#f1fcf2'
  on-background: '#141e18'
  surface-variant: '#dae5dc'
typography:
  display-lg:
    fontFamily: Tajawal
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.75rem
    letterSpacing: 0px
  display-lg-mobile:
    fontFamily: Tajawal
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: 0px
  headline-lg:
    fontFamily: Tajawal
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.6rem
    letterSpacing: 0px
  headline-lg-mobile:
    fontFamily: Tajawal
    fontSize: 1.625rem
    fontWeight: '700'
    lineHeight: 2.2rem
    letterSpacing: 0px
  headline-md:
    fontFamily: Tajawal
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2.1rem
    letterSpacing: 0px
  headline-sm:
    fontFamily: Tajawal
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: 1.75rem
    letterSpacing: 0px
  body-lg:
    fontFamily: Tajawal
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.85rem
    letterSpacing: 0px
  body-md:
    fontFamily: Tajawal
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.65rem
    letterSpacing: 0px
  body-sm:
    fontFamily: Tajawal
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.45rem
    letterSpacing: 0px
  label-lg:
    fontFamily: Tajawal
    fontSize: 0.9375rem
    fontWeight: '700'
    lineHeight: 1.35rem
    letterSpacing: 0px
  label-md:
    fontFamily: Tajawal
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0px
  label-sm:
    fontFamily: Tajawal
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies the calm, grounded elegance of indoor botany and artisan ceramics. Tailored for plant lovers and interior enthusiasts, the aesthetic pairs organic tranquility with editorial precision. 

### Emotional Tenets
- **Grounded Serenity:** Soft, tactile backgrounds and deep botanical foliage colors invoke an unhurried, peaceful shopping experience.
- **Warm Authority:** Knowledge-sharing interfaces feel encouraging, expert, and approachable—demystifying plant parenthood without clinical coldness.
- **Artisanal Craft:** Micro-details honor natural textures: raw clay, terracotta porosity, and the matte leaf surfaces of lush indoor foliage.

### Design Movement
**Refined Organic Modernism:** A hybrid of minimalist editorial layout and tactile, earthy realism. Interfaces favor generous whitespace, warm tonal backgrounds instead of harsh pure whites, subtle tinted borders, and gentle physical elevation cues reminiscent of ceramic forms and leaf layers.

## Colors

The palette is rooted in botanical flora, weathered terracotta clay, and unbleached fiber paper.

### Functional Roles
- **Primary (`#2A3B32` - Deep Forest Green):** Used for core branding moments, primary call-to-actions, structural navigations, and strong typography emphasis.
- **Secondary (`#8EA89D` - Muted Sage):** Deployed for subtle state highlights, tonal icon containers, secondary CTA backgrounds, and soft dividers.
- **Tertiary / Accent (`#C87D55` - Warm Terracotta):** Reserved for purchase interactions, sale indicators, urgency badges, stock indicators, and cart counters.
- **Surface & Backgrounds:**
  - Base Canvas (`#F9F8F5` - Natural Ivory): The overarching screen background.
  - Layered Surface (`#F3EFEA` - Earthy Linen): Card surfaces, modal drawers, and inset list backgrounds.
- **Typography & Content:**
  - High Contrast (`#1E2822` - Organic Charred Slate): Primary titles, body copy, and icons.
  - Low Contrast (`#5E6F65` - Foliage Shadow): Supporting text, metadata, disabled cues, and tertiary labels.

## Typography

The typographic system utilizes **Tajawal** across all breakpoints and text levels to provide natural, fluid Arabic reading mechanics and harmonious Latin balance.

### RTL Dynamics and Text Handling
- **Vertical Metric Calibration:** Arabic letterforms demand slightly higher line-height allocations (typically 1.45x–1.65x) to prevent overlap of marks, dots, and tall ascending diacritics.
- **Directional Alignment:** Default typography flows `right-to-left` (RTL). Numbers and currency labels preserve organic alignment next to corresponding copy.
- **Optical Tracking:** Avoid positive letter-spacing (`letterSpacing: 0px`) on connected Arabic glyphs to preserve natural cursive ligatures.

## Layout & Spacing

A structured fluid layout system grounded in an 8pt base grid ensures breathing room reminiscent of open architectural greenhouses.

### Breakpoint Matrix
- **Mobile (< 640px):** 4-column layout. Margin: `1.25rem`, Gutter: `1rem`. Full-width modular product cards and stacked checkout flows.
- **Tablet (640px – 1024px):** 8-column layout. Margin: `2rem`, Gutter: `1.25rem`. 2-column plant showcase cards with sticky contextual filters.
- **Desktop (> 1024px):** 12-column layout. Maximum content bounds constrained to `1280px`. Margin: `2.5rem`, Gutter: `1.5rem`. Multi-column product grid (3 or 4 columns) paired with persistent side navigation or deep drawer filters.

### Spacing Strategy
- Compact micro-gaps (`space-xs`, `space-sm`) are strictly reserved for badge insets, icon-to-label pairs, and variant chips.
- Structural component padding (`space-md`, `space-lg`) bounds card contents and input containers.
- Section divisions (`space-xl` and higher) give botanical imagery high spatial isolation.

## Elevation & Depth

This design system departs from generic gray drop shadows, using warm, plant-tinted ambient glows and layered surfaces to construct three-dimensional depth.

### Elevation Levels
- **Level 0 (Flat Ground):** `#F9F8F5` canvas with zero elevation.
- **Level 1 (Resting Ceramic):** Cards, bottom sheets, and containers resting on the canvas use surface `#F3EFEA` combined with a soft tinted boundary: `box-shadow: 0 4px 16px -2px rgba(42, 59, 50, 0.05); border: 1px solid rgba(42, 59, 50, 0.06);`.
- **Level 2 (Interactive Hover & Modals):** Triggered cards, dropdown menus, and quick-view popups utilize an expanded warm diffusion: `box-shadow: 0 12px 32px -4px rgba(42, 59, 50, 0.08), 0 4px 8px -2px rgba(200, 125, 85, 0.04);`.
- **Level 3 (Floating Actions & Drawers):** Cart FABs, notifications, and interactive care popups: `box-shadow: 0 16px 40px -6px rgba(30, 40, 34, 0.16);`.

## Shapes

The form language evokes hand-thrown pottery and soft plant leaves. 

- **Containers & Product Cards:** Employ level 2 rounding (`0.5rem` to `1rem` on desktop) to balance modern architectural framing with organic warmth.
- **Buttons, Badges & Care Chips:** Rely on full pill geometry (`9999px`) to create high touchability and friendly reassurance.
- **Ceramic Color Swatches:** Rendered as complete concentric circles with subtle inner bevels mimicking clay rims.

## Components

### Buttons
- **Primary Action:** Solid `#2A3B32` with `#F9F8F5` text, pill radius, padding `0.75rem 1.75rem`. On hover, transitions to subtle downward depth with background tint `#354a3f`.
- **Terracotta Accent (Checkout / Add to Bag):** Solid `#C87D55` with white text. High visual priority.
- **Secondary Action:** Transparent base with a 1.5px border of `#8EA89D`, text in `#2A3B32`.
- **Floating Action Button (FAB):** Circular (`56px x 56px`), `#2A3B32` background with `#F9F8F5` iconography, elevated at Level 3. Located at the bottom left for natural RTL thumb reach.

### Care Level & Light Badges (Pills)
- Compact pill-shaped metadata tags with an embedded botanical or sun pictogram.
- **Easy Care (سهلة العناية):** Background `#8EA89D` at 18% opacity, text `#2A3B32`.
- **Medium / Attention (متوسطة العناية):** Background `#EBDBCF`, text `#8A4C27`.
- **Light Requirement (محبة للضوء):** Background `#FAF2D6`, text `#6E5616`.

### Product & Botanical Cards
- Surface `#F3EFEA`, border-radius `1rem`, inset border `1px solid rgba(42, 59, 50, 0.05)`.
- Image container features a natural ivory backdrop (`#F9F8F5`) with `aspect-ratio: 4/5` and soft corner containment.
- Integrated care badge floating in the top-right corner of the image (RTL primary anchor).
- Quick ceramic pot swatch selector fixed near card base.

### Ceramic Color Swatch Selector
- Series of 24px circular discs showcasing earthy glazes (Terracotta Clay, Chalk White, Deep Basalt, Olive Mist).
- Selected state displays a 2px offset ring in `#2A3B32` with a 2px inner gap.

### Form Inputs & Text Fields
- Surface `#F9F8F5` with a baseline border of 1.5px in `#8EA89D` (30% opacity).
- Padding: `0.875rem 1rem`. Radius: `0.5rem`.
- Focus state: Border transitions to `#2A3B32` with an ambient glow of `rgba(42, 59, 50, 0.12)`. RTL label sits anchored to the right edge.

### Interactive Plant Care Popups & Drawers
- Mobile bottom-sheet or desktop centered modal featuring a ceramic textured header band.
- Sections broken down into micro-cards for: جدول الري (Watering Schedule), متطلبات الضوء (Light Influx), and درجة الحرارة والسماد (Humidity & Feeding).
- Close button positioned on the top-left corner honoring RTL visual hierarchy.